package Sabre.Sabre;

import java.io.FileNotFoundException;
import org.apache.log4j.PropertyConfigurator;

/**
 * @author M1042113
 */
public final class Logs {

    /**
     * Prints Statement
     * 
     * @throws FileNotFoundException
     */
    private Logs() {
        PropertyConfigurator.configure(System.getProperty("user.dir") + "/src/test/resources/log4j.properties");
    }

    public static void Ulog(String statement) {
        Testbase.TTlogs.info(statement);
    }

    public static void debug(String message, String exception) {
        Testbase.TTlogs.debug(message + exception);

    }
}


