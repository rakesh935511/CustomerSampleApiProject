package Sabre.Sabre;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;
import static io.restassured.RestAssured.given;

import org.json.JSONException;


import org.testng.Assert;

import org.testng.annotations.Test;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
public class All_Test_Executed_at_one_Go extends Testbase {
	
	
     @Test(priority=0)
	public  void get_Method_all_Customer() throws JSONException  {
              response=  given()
				         .when()
				         .get(baseUri+"Customers")
				         .then()
				         .log().body().extract().response();
		      js1=new JsonPath(response.asString());
		      ExtentTestManager.logsGeneration(response.asString());
		      ExtentTestManager.logsGeneration("Storing this Response data for validating other Customer Data");
		          }
	
     @Test(priority=1)
 	public  void get_Method_particular_Customer_1111() throws JSONException  {
    	 response= given()
				   .when()
				   .get(baseUri+js1.get("data["+i+"].id")+"/CustomerView")
				   .then()
				   .log().body().extract().response();
      ExtentTestManager.logsGeneration(response.asString());	 
      ExtentTestManager.logsGeneration("Sending Customer ID as:- "+js1.get("data["+i+"].id"));
      ExtentTestManager.logsGeneration("Validating id,Email,First_Name&Last_Name");
      
       }
	
     @Test(priority=2)
 	public  void get_Method_particular_Customer_2222() throws JSONException  {
    	 
		         response=   given()
					   .when()
					   .get(baseUri+js1.get("data["+i+"].id")+"/CustomerView").
					   then()
					   .log().body().extract().response();
		ExtentTestManager.logsGeneration("Sending Customer ID as:- "+js1.get("data["+i+"].id"));
		Validation.validate(response);

     }
	
     @Test(priority=3)
 	public  void get_Method_particular_Customer_3333() throws JSONException  {
    	
		        response=given()
					   .when()
					   .get(baseUri+js1.get("data["+i+"].id")+"/CustomerView").
					   then()
					   .log().body().extract().response();
		ExtentTestManager.logsGeneration("Sending Customer ID as:- "+js1.get("data["+i+"].id"));
		Validation.validate(response);           

     }

     @Test(priority=4)
 	public  void get_Method_particular_Customer_4444() throws JSONException  {
		           response= given()
					   .when()
					   .get(baseUri+js1.get("data["+i+"].id")+"/CustomerView").
					   then()
					   .log().body().extract().response();
		            ExtentTestManager.logsGeneration("Sending Customer ID as:- "+js1.get("data["+i+"].id"));
		            Validation.validate(response);           

     }
	 
     @Test(priority=5)
 	public  void get_Method_particular_Customer_5555() throws JSONException  {
    	
		            response=given()
					   .when()
					   .get(baseUri+js1.get("data["+i+"].id")+"/CustomerView").
					   then()
					   .log().body().extract().response();
		            ExtentTestManager.logsGeneration("Sending Customer ID as:- "+js1.get("data["+i+"].id"));
		            Validation.validate(response);		            

     }
	
     @Test(priority=6)
 	public  void get_Method_particular_Customer6_6666() throws JSONException  {
    	 
		    response=  given()
					   .when()
					   .get(baseUri+js1.get("data["+i+"].id")+"/CustomerView").
					   then()
					   .log().body().extract().response();
		            ExtentTestManager.logsGeneration("Sending Customer ID as:- "+js1.get("data["+i+"].id"));
		            Validation.validate(response);		            

     }
	
     @Test(priority=7)
 	public  void get_Method_particular_Customer_11() throws JSONException  {
    	 
		          response=  given()
					   .when()
					   .get(baseUri+"785"+"/CustomerView").
					   then()
					   .log().body().extract().response();
		          Assert.assertEquals(response.getStatusCode(),404);
		    	  ExtentTestManager.logsGeneration("Status code is Validated as "+response.getStatusCode());
		    	  JsonPath jpath=new JsonPath(response.asString());
		    	  Assert.assertEquals(jpath.get("status"),"fail");
			      ExtentTestManager.logsGeneration("Status  is Validated as "+jpath.get("status"));
			      Assert.assertEquals(jpath.get("message"),"Customer details not found.");
			      ExtentTestManager.logsGeneration("message  is Validated as "+jpath.get("message"));

     }
    
 	
		
		}