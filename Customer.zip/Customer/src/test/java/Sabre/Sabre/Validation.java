package Sabre.Sabre;

import org.testng.Assert;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Validation extends Testbase {
	public static void validate(Response response) {
		if(i!=0)
		{ Assert.assertEquals(response.getStatusCode(),200);
 		ExtentTestManager.logsGeneration("Status code is Validated as "+response.getStatusCode());
		JsonPath js=new JsonPath(response.asString());
		 Assert.assertEquals(js.get("status"),"success");
		ExtentTestManager.logsGeneration("Status Success is Validated");
		 ExtentTestManager.logsGeneration(js.get("data.customerID")+" Customer ID is Validated");
		 Assert.assertEquals(js.get("data.email"),js1.get("data["+i+"].email"));
		 ExtentTestManager.logsGeneration(js.get("data.email")+ " Email Address is Verified");
		Assert.assertEquals(js.get("data.first_name"),js1.get("data["+i+"].first_name"));
		ExtentTestManager.logsGeneration(js.get("data.first_name")+ " As First Name is Verified");
		 Assert.assertEquals(js.get("data.last_name"),js1.get("data["+i+"].last_name"));
		 ExtentTestManager.logsGeneration(js.get("data.last_name")+ " As Last Name is Verified");
		 ExtentTestManager.logsGeneration("Verified All Data");
		}
		else
		{Assert.assertEquals(response.getStatusCode(),200);
 		ExtentTestManager.logsGeneration("Status code is Validated as "+response.getStatusCode());
		JsonPath js=new JsonPath(response.asString());
		 Assert.assertEquals(js.get("status"),"success");
		ExtentTestManager.logsGeneration("Status Success is Validated");
		 ExtentTestManager.logsGeneration(js.get("data.customerID")+" Customer ID is Validated");
		 Assert.assertEquals(js.get("data.email"),js1.get("data["+i+"].email"));
		 ExtentTestManager.logsGeneration(js.get("data.email")+ " Email Address is Verified");
		 ExtentTestManager.logsGeneration("Verified All Data");
	    }
	}
}
