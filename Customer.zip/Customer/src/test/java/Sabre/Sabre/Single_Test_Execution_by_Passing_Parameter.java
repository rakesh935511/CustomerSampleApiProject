package Sabre.Sabre;

import static io.restassured.RestAssured.given;

import org.json.JSONException;
import org.testng.Assert;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class Single_Test_Execution_by_Passing_Parameter extends Testbase {
	 @Parameters({"custumerid"})
     @Test()
  	public  void get_Method_particular_Customer_anyvalue(String custumerid) throws JSONException  {
     	
 		           Response response=given()
 					   .when()
 					   .get(baseUri+custumerid+"/CustomerView").
 					   then()
 					   .log().body().extract().response();
 		           ExtentTestManager.logsGeneration(response.asString());
 		            JsonPath jscheck=new JsonPath(response.asString());
 		            ExtentTestManager.logsGeneration("Sending Customer ID as:- "+custumerid);
 		           Assert.assertEquals(response.getStatusCode(),200);
 		   		ExtentTestManager.logsGeneration("Status code is Validated as "+response.getStatusCode());
 		   	 Assert.assertEquals(jscheck.get("status"),"success");
 			ExtentTestManager.logsGeneration("Status Success is Validated");
 		            	            

      }

}
