package Sabre.Sabre;



import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Properties;
import java.util.TreeMap;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.Dimension;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.relevantcodes.extentreports.LogStatus;



public class FunctionLibrary {
     /**
     * @return system time in MM_dd_yyyy_h_mm_ss_a format
     */
    public static String systemTimeStamp() {

        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("MM_dd_yyyy_h_mm_ss_a");
        return sdf.format(date);
    }

    /*
     * To append to the pwd created this method(for dynamic purpose) Ruturaj
     */
    public static String sysTimeStamp() {

        Date date = new Date();
        SimpleDateFormat sdf = new SimpleDateFormat("h_mm_ss");
        return sdf.format(date);
    }
    



   

}

