package Sabre.Sabre;
   
	import com.relevantcodes.extentreports.ExtentReports;

	public class ExtentManager {

	    private static ExtentReports instance;
	    public static final String EXTENT_REPORT_PATH = System.getProperty("user.dir") + "/target/Reports/";

	    public static synchronized ExtentReports getInstance() {
	        if (instance == null) {
	            Logs.Ulog(System.getProperty("user.dir"));
	            String time = FunctionLibrary.systemTimeStamp();
	            instance = new ExtentReports(EXTENT_REPORT_PATH + "AutomationReport_" + time + ".html");
	        }

	        return instance;
	    }

	   

	   
	}

