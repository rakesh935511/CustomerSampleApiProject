package Sabre.Sabre;


import java.util.HashMap;
import java.util.Map;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;



public class ExtentTestManager {
    protected static ExtentTest test;
    protected static final Map<Integer, ExtentTest> EXTENT_TEST_MAP = new HashMap<Integer, ExtentTest>();
    public static final ExtentReports EXTENT = ExtentManager.getInstance();

    public static synchronized ExtentTest getTest() {
        return EXTENT_TEST_MAP.get((int) (Thread.currentThread().getId()));
    }

    public static synchronized void endTest() {
    
        EXTENT.endTest(EXTENT_TEST_MAP.get((int) (Thread.currentThread().getId())));
    }
    public static synchronized void testcompleted(String testName) {
    	test.log(LogStatus.INFO, "Execution Completed of:"+ testName);

    }
  
    public static synchronized ExtentTest startTest(String testName) {
        return startTest(testName, "");
    }

    public static synchronized ExtentTest startTest(String testName, String desc) {
        test = EXTENT.startTest(testName, desc);
        test.log(LogStatus.INFO, "Started execution of : " + testName);
        EXTENT_TEST_MAP.put((int) (Thread.currentThread().getId()), test);
        return test;
    }

    public static synchronized void logsGeneration(String message) {
        test.log(LogStatus.INFO, message);
    }
}