package Sabre.Sabre;
import org.apache.log4j.Logger;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.Optional;
import org.testng.annotations.Parameters;
import Sabre.Sabre.ExtentTestManager;
import Sabre.Sabre.Logs;
import java.lang.reflect.Method;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;
public class Testbase  {
	 public static String baseUri="http://localhost:4547/Blog.Api/";
	public static JsonPath js1;
	public static int i=-1;
	public static Response response;
	   public static String extentReportPath = System.getProperty("user.dir") + "/target/Reports/";
	   
	    public static String FILE_LOCATION = "";
	    static Logger TTlogs = Logger.getLogger(Testbase.class);
	   

	    @BeforeMethod
	    @Parameters()
	    public static void setUp(Method caller) {
	    	ExtentTestManager.startTest(caller.getName());
	        //Logs.Ulog("Loggging started..");
	  
			
			
	    }

	@AfterMethod()
	public void afterMethod(@Optional Method caller) {
		ExtentTestManager.testcompleted(caller.getName());
		i++;
	}
	 
	     @AfterTest 
	      public void cleanup() {
	       ExtentTestManager.endTest(); 
	       ExtentManager.getInstance().flush();
	      
	      }

	  
	     
				
	    
	     }
	

